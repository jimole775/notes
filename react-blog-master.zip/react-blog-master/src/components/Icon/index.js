'use strict'

import React from 'react'

const Icon = ({ iconName, className }) => (
  <i className={'material-icons ' + className}>{iconName}</i>
)

Icon.propTypes = {
  iconName     : React.PropTypes.string.isRequired,
  className : React.PropTypes.string
}

export default Icon
