import React, { Component } from 'react'
import Icon from '../../components/Icon'
// export const Collection = (props) => (
//   <ul className="collection ">
//     {props.list.forEach((value)=>{
//       ( <li className="collection-item cyan">hello world</li> )
//     })}
//   </ul>
// )
let styles = {
  block: {
    display: 'block'
  }
}

class Collection extends Component {
  render () {
    let props = this.props
    // let list = this.state.list || []
    return (
      <ul className='collection'>
        {props.list.map((text, i) => {
          return (
            <li style={styles.block} className='collection-item cyan  waves-effect waves-light' key={i}>
              {text}
              <span className='secondary-content' onClick={(e) => {
                props.clickHandler(i)
              }}>
                <Icon iconName='close' className='black-text ' />
              </span>
            </li>)
        })}
      </ul>
    )
  }
}

export default Collection
