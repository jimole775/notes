import React from 'react'
import { IndexLink, Link } from 'react-router'
import './Header.scss'

export const Header = () => (
  <div className='navbar-fixed'>
    <nav className='cyan darken-2 row waves-effect waves-light'>
      <div className='nav-wrapper container '>
        <IndexLink to='/' className='brand-logo'>sydeEvans</IndexLink>
        <ul id='nav-mobile' className='right hide-on-med-and-down'>
          <li><Link to='post'>post</Link></li>
          <li><Link to='about'>about</Link></li>
          <li><Link to='counter'>counter</Link></li>
          <li><Link to='todo'>Todo Mvc</Link></li>
        </ul>
      </div>
    </nav>
  </div>
)

export default Header
