'use strict'

import { connect } from 'react-redux'
import { add, deleteItem } from '../store/todo'

import Todo from '../components/Todo'

const mapDispatchToProps = {
  add,
  deleteItem
}

const mapStateToProps = (state) => ({
  todos : state.todos
})

export default connect(mapStateToProps, mapDispatchToProps)(Todo)
