'use strict'

// ------------------------------------
// Constants
// ------------------------------------
export const ADD_TODO = 'ADD_TODO'
export const DELETE_TODO = 'DELETE_TODO'
// ------------------------------------
// Actions
// ------------------------------------
export function add(text) {
  return {
    type: ADD_TODO,
    payload: text
  }
}

export function deleteItem(id) {
  return {
    type: DELETE_TODO,
    payload: id
  }
}

export const actions = {
  add,
  deleteItem
}

// ------------------------------------
// Action Handlers
// ------------------------------------
const ACTION_HANDLERS = {
  [ADD_TODO]: (state, action) => [...state, action.payload],
  [DELETE_TODO]: (state, action) => state.filter((item)=>item != state[action.payload])
}

// ------------------------------------
// Reducer
// ------------------------------------
export default function todoReducer(state = [], action) {
  const handler = ACTION_HANDLERS[action.type]

  return handler ? handler(state, action) : state
}
