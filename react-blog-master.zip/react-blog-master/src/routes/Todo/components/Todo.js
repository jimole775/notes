'use strict'

import React, { Component } from 'react'
import Collection from '../../../components/Collection'
import Icon from '../../../components/Icon'
const ENTER_KEY = 13

class Todo extends Component {
  render () {
    let props = this.props
    let input
    return (
      <div style={{ margin: '0 auto' }}>
        <h2>Todo MVC</h2>

        <div className='row'>
          <form className='col s12'>
            <div className='row'>
              <div className='input-field col s6'>
                <Icon className='prefix' iconName='mode_edit' />
                <input id='icon_telephone' type='text' className='validate'
                  ref={node => {
                    input = node
                  }}
                  onKeyDown={(e) => {
                    if (e.keyCode !== ENTER_KEY) {
                      return
                    }
                    if (!input.value.trim()) {
                      return
                    }
                    e.preventDefault()

                    props.add(input.value)
                    input.value = ''
                  }} />
                <label htmlFor='icon_telephone'>What need to be done?</label>
              </div>
            </div>
          </form>

          <div className='col s12'>
            <Collection list={props.todos} clickHandler={props.deleteItem} />
          </div>

        </div>

      </div>
    )
  }
}

export default Todo
