# redux记录

action: 一个js对象，描述状态的变化  
dispatch: 接收action，执行相应的reducer
reducer： 一个纯函数

# 一个todo应用的典型store
```js
{
  visibilityFilter: 'SHOW_ALL',
  todos: [
    {
      text: 'Consider using Redux',
      completed: true,
    },
    {
      text: 'Keep all state in a single tree',
      completed: false
    }
  ]
}
```