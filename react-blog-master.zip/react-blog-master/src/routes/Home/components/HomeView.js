import React from 'react'
import Link from 'react-router/lib/Link'
import Image from '../assets/1.jpg'
import './HomeView.scss'

let styles = {
  largeFont: {
    fontSize: '50px'
  },
  bg: {
    backgroundImage: `url(${Image})`
  },
  op: {
    opacity: '0.7'
  }
}

export const HomeView = () => (
  <div className="row">
    <div className="col s3">
      <div className="card cyan">
        <div className="card-content white-text">
          <h1>归档</h1>
          <p>javascript</p>
          <p>nodejs</p>
          <p>golang</p>
          <p>javascript</p>
          <p>nodejs</p>
          <p>golang</p>
        </div>
      </div>

      <div className="card cyan">
        <div className="card-content white-text">
          <h1>tags:</h1>
          <p>javascript</p>
          <p>nodejs</p>
          <p>golang</p>
          <p>javascript</p>
          <p>nodejs</p>
          <p>golang</p>
        </div>
      </div>

      <div className="card cyan ">
        <div className="card-content white-text">
          <span className="card-title">About me</span>
          <p>
            这个世界需要英雄 ！！
          </p>
        </div>
        <div className="card-action">
          <Link to="#">github</Link>
          <Link to="#">weibo</Link>
        </div>
      </div>

    </div>
    <div className="col s9">
      <div className='container-fluid card cyan z-depth-2 waves-effect waves-light'>
        <div className='cover z-depth-1' style={styles.bg}>
          <div className='filter cyan' style={styles.op}>
            <div className='cover-text cyan-text text-darken-4'>
              <span style={styles.largeFont}>&lt; nodejs 查漏补缺 /&gt;</span>
            </div>
          </div>
        </div>
        <div className='card-content white-text'>
          <div className='card-title'>
            <h4>about-me</h4>
          </div>
          <div>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam vel purus sagittis, eleifend ante quis,
            tempus
            lectus. Vivamus maximus nibh lectus, sed gravida sapien imperdiet in.
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam vel purus sagittis, eleifend ante quis,
            tempus
            lectus. Vivamus maximus nibh lectus, sed gravida sapien imperdiet in.
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam vel purus sagittis, eleifend ante quis,
            tempus
            lectus. Vivamus maximus nibh lectus, sed gravida sapien imperdiet in.
          </div>
        </div>
      </div>

      <h5 className="cyan-text">近期文章</h5>
      <div className="card cyan darken-1">
        <div className="card-content white-text">
          <span className="card-title">Card Title</span>
          <p>I am a very simple card. I am good at containing small bits of information.
            I am convenient because I require little markup to use effectively.</p>
        </div>
        <div className="card-action">
          <Link to="#"> >>>查看全文</Link>
        </div>
      </div>
      <div className="card cyan darken-1">
        <div className="card-content white-text">
          <span className="card-title">Card Title</span>
          <p>I am a very simple card. I am good at containing small bits of information.
            I am convenient because I require little markup to use effectively.</p>
        </div>
        <div className="card-action">
          <Link to="#"> >>>查看全文</Link>
        </div>
      </div>


    </div>
  </div>
)
/**
 <div className='container-fluid card cyan z-depth-2 waves-effect waves-light'>
 <div className='cover z-depth-1' style={styles.bg}>
 <div className='filter cyan' style={styles.op}>
 <div className='cover-text cyan-text text-darken-4'>
 <span style={styles.largeFont}>&lt; about-me /&gt;</span>
 </div>
 </div>
 </div>
 <div className='card-content white-text'>
 <div className='card-title'>
 <h4>about-me</h4>
 </div>
 <div>
 Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam vel purus sagittis, eleifend ante quis, tempus
 lectus. Vivamus maximus nibh lectus, sed gravida sapien imperdiet in.
 </div>
 </div>
 </div>
 */
export default HomeView
