import HomeView from './components/HomeView'

// Sync route definition
export default {
  component : HomeView
}
