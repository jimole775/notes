import React from 'react'
import Header from '../../components/Header'
import './CoreLayout.scss'
import '../../styles/core.scss'

export const CoreLayout = ({ children }) => (
  <div className='had-container text-center'>
    <Header />
    <div className='core-layout__viewport container'>
      {children}
    </div>

    <footer className="page-footer cyan">
      <div className="footer-copyright">
        <div className="container">
          © 2014-2016 Materialize, All rights reserved.
          <a className="grey-text text-lighten-4 right" href="#!">More Links</a>
        </div>
      </div>
    </footer>
  </div>
)

CoreLayout.propTypes = {
  children : React.PropTypes.element.isRequired
}

export default CoreLayout
