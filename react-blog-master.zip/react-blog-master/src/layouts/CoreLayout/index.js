import CoreLayout from './CoreLayout'

export default CoreLayout
