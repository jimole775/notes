require("babel-register")({
  // cacheDirectory : true,
  plugins        : ['transform-runtime'],
  presets        : ['es2015', 'react', 'stage-0']
})
require('../src/server-render')
